"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VIDEO_KEY = "data-ssrc";
var meetingId = document.location.pathname.slice(1);
var Job = /** @class */ (function () {
    function Job(name, callback) {
        this.name = name;
        this.callback = callback;
        this.timeout = setTimeout(function () { }, 1);
        this.interval = setInterval(function () { }, Number.MAX_VALUE);
    }
    Job.prototype.schedule = function (timeout) {
        if (timeout === void 0) { timeout = 1; }
        clearTimeout(this.timeout);
        this.timeout = setTimeout(this.callback, timeout);
    };
    Job.prototype.repeat = function (timeout) {
        if (timeout === void 0) { timeout = 1000; }
        clearInterval(this.interval);
        this.interval = setInterval(this.callback, timeout);
    };
    Job.prototype.cancel = function () {
        clearTimeout(this.timeout);
        clearInterval(this.interval);
    };
    return Job;
}());
exports.Job = Job;
;
function getUserId() {
    var you = $("div[data-self-name=\"You\"]").filter(function (index, element) {
        return $(element).text() === "You";
    });
    var container = you.closest("div[jsmodel]");
    var videoParent = container.find("div[data-ssrc]");
    return videoParent.attr("data-ssrc");
}
exports.getUserId = getUserId;
function log() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    console.log.apply(console, ["HappyMeet:"].concat(args));
}
exports.log = log;
function debug() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    // console.log("HappyMeet:", ...args);
}
exports.debug = debug;
function sendMessage(message) {
    message.meetingId = meetingId;
    log("sendMessage", message);
    chrome.runtime.sendMessage(message, function (response) {
        // OK
    });
}
exports.sendMessage = sendMessage;

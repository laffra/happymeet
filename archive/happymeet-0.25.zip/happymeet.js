"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var emojis_1 = require("./emojis");
var util_1 = require("./util");
var HappyMeet = /** @class */ (function () {
    function HappyMeet() {
        this.domChecker = new util_1.Job("DOM Checker", this.check.bind(this));
        var happymeet = this;
        $("body").on("DOMSubtreeModified", function () {
            happymeet.domChecker.schedule(100);
        });
        util_1.sendMessage({
            type: "start-meeting",
        });
        chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
            switch (message.type) {
                case "emoji":
                    animateEmoji(message.userId, message.emoji);
                    sendResponse("OK");
                    break;
            }
        });
    }
    HappyMeet.prototype.check = function () {
        addEmojiButton();
    };
    return HappyMeet;
}());
function addEmojiButton() {
    if ($(".happymeet-emojis-button").position())
        return;
    addEmojiButtonNew();
    addEmojiButtonOld();
}
exports.addEmojiButton = addEmojiButton;
function addEmojiButtonOld() {
    var button = $("div[aria-label=\"Leave call\"]");
    var buttonDiv = button.parent();
    buttonDiv.after($("<div>")
        .attr("class", buttonDiv.attr("class"))
        .append($("<button>")
        .attr("class", button.attr("class"))
        .addClass("happymeet-emojis-button")
        .css({
        padding: 5,
        fontSize: 36,
    })
        .on("mousedown", showEmojis)
        .text("😊")));
}
exports.addEmojiButtonOld = addEmojiButtonOld;
function addEmojiButtonNew() {
    var button = $("span:contains(\"closed_caption\")").closest("button");
    var buttonDiv = button.parent().parent().parent();
    buttonDiv.after($("<div>")
        .attr("class", button.parent().parent().parent().attr("class"))
        .append($("<div>")
        .attr("class", button.parent().parent().attr("class"))
        .append($("<span>")
        .attr("class", button.parent().attr("class"))
        .append($("<button>")
        .attr("class", button.attr("class"))
        .addClass("happymeet-emojis-button")
        .css("padding", 5)
        .on("mousedown", showEmojis)
        .text("😊")))));
}
exports.addEmojiButtonNew = addEmojiButtonNew;
function showEmojis() {
    var dialog = $(".happymeet-emojis-dialog");
    if (!dialog.position()) {
        dialogDiv.find("button").css("display", "none");
        dialog = dialogDiv.dialog({
            height: 200,
            width: 600,
            closeOnEscape: true,
            title: 'HappyMeet: Send an Emoji to all attendees...',
        });
        setTimeout(filterEmojis, 1);
    }
    dialog.dialog("open");
    $(".ui-icon-closethick")
        .text("x")
        .css({
        color: "black",
    });
}
function animateEmoji(userId, emoji) {
    var video = $("div[data-ssrc=\"" + userId + "\"]").last().parent();
    util_1.debug("show emoji", userId, emoji, video.position());
    if (!video.offset())
        return;
    video.find(".happymeet-emoji").remove();
    $("<div>")
        .addClass("happymeet-emoji")
        .appendTo(video)
        .css({
        left: 0,
        marginLeft: 12,
        marginTop: 8,
        opacity: 1,
        zIndex: 1000,
    })
        .text(emoji)
        .animate({
        opacity: 0,
    }, 25000, "linear", function () { $(this).remove(); });
    var middle = video.offset().left + video.width() / 2 - 20;
    var center = video.offset().top + video.height() / 2 - 30;
    for (var angle = 0; angle < Math.PI * 2; angle += Math.PI / 6) {
        var left = middle + Math.cos(angle) * 800;
        var top_1 = center + Math.sin(angle) * 800;
        $("<div>")
            .addClass("happymeet-emoji")
            .appendTo($("body"))
            .text(emoji)
            .css({
            fontSize: 60,
            left: middle,
            top: center,
        })
            .animate({
            fontSize: 22,
            left: left,
            top: top_1,
            opacity: 0.3,
        }, 3000, "linear", function () { $(this).remove(); });
    }
}
var dialogDiv = createDialogDiv();
function filterEmojis() {
    var div = $(".happymeet-emojis-dialog");
    var searchString = $(".happymeet-emoji-filter").val();
    div.find("button").css("display", "inline-block");
    div.find("button").each(function (index, element) {
        var button = $(element);
        if (!button.attr("search").match(new RegExp(searchString, "i"))) {
            button.css("display", "none");
        }
    });
}
function createDialogDiv() {
    var search = $("<input>")
        .attr("placeholder", "search")
        .addClass("happymeet-emoji-filter")
        .css({
        fontSize: 18,
    })
        .on("keyup", filterEmojis);
    var emojis = $("<div>")
        .addClass("happymeet-emoji-container");
    emojis_1.EMOJIS.forEach(function (entry) {
        $("<button>")
            .text(entry.emoji)
            .attr("name", entry.name)
            .attr("category", entry.category)
            .attr("search", entry.name + " " + entry.category)
            .css("display", "none")
            .on("click", function () {
            util_1.sendMessage({
                type: "emoji",
                userId: util_1.getUserId(),
                emoji: entry.emoji,
            });
        })
            .appendTo(emojis);
    });
    return $("<div>")
        .addClass("happymeet-emojis-dialog")
        .css("background-color", "white")
        .on("scroll", function () {
        search.css("top", $(".happymeet-emojis-dialog").scrollTop() + 8);
    })
        .append(search, emojis);
}
new HappyMeet();

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var util_1 = require("./util");
var Presentation = /** @class */ (function () {
    function Presentation(video, userId) {
        this.userId = userId;
        this.video = video;
        this.live = !(video.css("display") === "none");
        this.videoParent = video.parent();
        Presentation.singleton = this;
        $(".happymeet .presentation")
            .append(video.addClass("happymeet"));
    }
    Presentation.prototype.reparentVideo = function () {
        this.video
            .css("opacity", 1)
            .removeClass("happymeet")
            .appendTo(this.videoParent);
    };
    Presentation.reparentVideos = function () {
        if (Presentation.singleton) {
            Presentation.singleton.reparentVideo();
        }
    };
    Presentation.check = function () {
        if (!Presentation.singleton)
            return;
        if (Presentation.singleton.video.css("display") !== "none") {
            if (!Presentation.singleton.live) {
                util_1.sendMessage({
                    type: "presentation-start",
                    userId: Presentation.singleton.userId,
                });
            }
            Presentation.singleton.live = true;
        }
        if (!Presentation.singleton.live)
            return;
        if (Presentation.singleton.video.css("display") === "none") {
            Presentation.singleton.live = false;
            util_1.sendMessage({
                type: "presentation-stop",
                userId: Presentation.singleton.userId,
            });
        }
    };
    Presentation.isPresentation = function (container, video) {
        if (container.find("svg").length >= 10)
            return false;
        var name = util_1.findNameElementFromVideo(video).text();
        if (name.startsWith("Presentation ("))
            return true;
        return false;
    };
    return Presentation;
}());
exports.Presentation = Presentation;
;
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    switch (message.type) {
        case "start-meeting":
            if (!Presentation.singleton)
                break;
            if (!Presentation.singleton.video)
                break;
            if (Presentation.singleton.video.css("display") !== "none") {
                util_1.sendMessage({
                    type: "presentation-start",
                    userId: Presentation.singleton.userId,
                });
            }
            sendResponse("OK");
            break;
        case "presentation-stop":
            $(".presentation .message")
                .empty()
                .append($("<div>").text("Waiting for someone to present..."));
            sendResponse("OK");
            break;
        case "presentation-start":
            $(".presentation .message")
                .empty()
                .append($("<div>").text("Presentation should appear here."), $("<div>").text("This may take a few seconds."), $("<div>").text("In case of problems, refresh the window."));
            sendResponse("OK");
            break;
    }
});
function findPresentationPreview() {
    $("div[data-fps-request-cap] video").each(function (n, element) {
        var video = $(element);
        var div = video.closest("div[data-fps-request-cap]");
        if (div.parent().text().slice(0, 18) == "Presentation (You)") {
            new Presentation(video, "");
        }
    });
}
exports.findPresentationPreview = findPresentationPreview;
